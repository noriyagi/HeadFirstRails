class ClientWorkout < ActiveRecord::Base
end
