class Incident < ActiveRecord::Base
end
