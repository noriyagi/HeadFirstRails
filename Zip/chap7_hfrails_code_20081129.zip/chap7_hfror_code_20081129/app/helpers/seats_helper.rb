module SeatsHelper
end
