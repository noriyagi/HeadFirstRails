module IncidentsHelper
end
